<?php
    set_time_limit(0);
    error_reporting(-1);
    require_once ( 'dbconnect.php' );

    $sql    = "UPDATE `ebay_seller` SET `data_status`='0'";
    $result = mysql_query ($sql);

    $sql    = "UPDATE `ebay_item` SET `sold_status`='0', `date_updated`='".date('Y-m-d H:i:s')."'";
    $result = mysql_query ($sql);
	
	$sql    = "TRUNCATE TABLE `ebay_purchase_history`";
    mysql_query ($sql);
	
	$sql    = "INSERT INTO `ebay_reset`(`reset_time`) VALUES(NOW());";
    mysql_query ($sql);
	
    echo "\nENDED";