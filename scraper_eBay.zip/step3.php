<?php
    set_time_limit(0);
    // Report all PHP errors
    error_reporting(-1);
    //error_reporting(0);
    require_once ( 'dbconnect.php' );

    $sql    = "SELECT * FROM `ebay_seller` WHERE `data_status`='2' ORDER BY id ASC LIMIT 0,100;";
    $result = mysql_query ($sql);

    while ($row = mysql_fetch_object ($result))
	{
		$id              = $row->id;
		$scan_id         = $row->id;
		echo $row->username.'<br>';
		$ITEM_COUNT      = getProdcountByScan ($scan_id);
		$ITEM_COUNT_PENDING    = getProdPendingcountByScan ($scan_id);
		$ITEM_COUNT_DONE = getProdDonecountByScan ($scan_id);
		echo "ITEM_COUNT:$ITEM_COUNT<br>" ;
		echo "ITEM_COUNT_PENDING:$ITEM_COUNT_PENDING<br>" ;
		echo "ITEM_COUNT_DONE:$ITEM_COUNT_DONE<br>" ;
		if ( $ITEM_COUNT_PENDING==0 && $ITEM_COUNT_DONE==$ITEM_COUNT )
        {
			echo' Done';
			updateEbayScanStatus ( $id, 3 ); //everything done
        }
	}

	echo "\nENDED"; exit;
	

	function getProdcountByScan ($scan_id)
	{
	    $sql    = "SELECT COUNT(*) AS total FROM `ebay_item` WHERE `scan_id`='$scan_id';";
	    $result = mysql_query ( $sql );
	    $row    = mysql_fetch_object ( $result );
		
	    return $row->total;
	}
	function getProdPendingcountByScan ($scan_id)
	{
	    $sql    = "SELECT COUNT(*) AS total FROM `ebay_item` WHERE `scan_id`='$scan_id' AND sold_status='0';";
	    $result = mysql_query ( $sql );
	    $row    = mysql_fetch_object ( $result );
		
	    return $row->total;
	}
	function getProdDonecountByScan ($scan_id)
	{
	    $sql    = "SELECT COUNT(*) AS total FROM `ebay_item` WHERE `scan_id`='$scan_id' AND `sold_status`='2';";
	    $result = mysql_query ( $sql );
	    $row    = mysql_fetch_object ( $result );

	    return $row->total;
	}
	
	
