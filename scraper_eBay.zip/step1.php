<?php
	//Turn off all error reporting
	//error_reporting(0);

	//Report all PHP errors
	error_reporting(-1);

	// Report simple running errors
	//error_reporting(E_ERROR | E_WARNING | E_PARSE);

	set_time_limit(0);
	require_once ('dbconnect.php');

    $msql    = "SELECT * FROM `ebay_seller` WHERE `data_status`='0'  ORDER BY id ASC LIMIT 0 , 10;";
    $mResult = mysql_query ($msql);

    while ( $mRow = mysql_fetch_object ($mResult))
    {
    	$id       = $mRow->id;
    	$scan_id  = $id;
    	$username = $mRow->username;
		updateEbayScanStatus ($id, -1);// getting items

		if (! isValidEbayUser ($username))
		{
			updateEbayScanStatus ($id, -1);//INVALID SELLER
			continue;
		}
				
		$target_url   = "https://www.ebay.com/sch/m.html?_ssn=$username&_ipg=200&_sop=13&LH_Complete=1&LH_Sold=1&rt=nc";


		$contents   = getEbayUSAPage ( $target_url );
		file_put_contents('US.html', $contents);
		$feedbackScore = getValueByEnclosedString($contents, 'Feedback score of', 'href="');
		$feedbackScore = str_replace ('"', '', $feedbackScore);
		$feedbackScore = str_replace (' ', '', $feedbackScore);
		saveEbayFeedback($username,$feedbackScore);
		
		//	get country
		$html   = getEbayStore( 'http://www.ebay.com/usr/'.$username,'www.ebay.com');
		$internalErrors = libxml_use_internal_errors(true);
		$doc = new DOMDocument();
		$doc->loadHTML($html);
		$xpath = new DOMXpath($doc);
		libxml_use_internal_errors($internalErrors);
		$trNodes = $xpath->query("//span[@class='mem_loc']");
		$country = $trNodes->item(0)->nodeValue;
		saveEbayCountry($username,$country);
		
		
		$contents   = getValueByEnclosedString($contents, 'id="Results"', 'id="PaginationAndExpansionsContainer"');
		$contents   = explode ('id="item', $contents);
		array_shift ($contents);

		foreach ($contents as $thisContent)
		{
			$item           = getBlankItem ();
			$item->scan_id  = $scan_id;
			$item->username = $username;

			$item->title  = cleanData(strip_tags(getValueByEnclosedString($thisContent, '<h3 class="lvtitle">', '</h3>')));
			$item->price  = cleanData(strip_tags(getValueByEnclosedString($thisContent, '<li class="lvprice prc">', '</')));
			$item->price  = str_replace ('Trending at', '', $item->price);
			$item->img    = cleanData(strip_tags(getValueByEnclosedString($thisContent, 'src="', '"')));
			$item->source = cleanData(strip_tags(getValueByEnclosedString($thisContent, '<a href="', '"')));

			preg_match_all ('/-\/(.*)\?hash=/', $item->source, $matches);
			$matches   = array_unique($matches[1]);
			$item->itm = array_shift ($matches);

			if ( $item->itm == '' )
			{
				preg_match_all ('/-\/(.*)\?var=/', $item->source, $matches);
				$matches   = array_unique($matches[1]);
				$item->itm = array_shift ($matches);
			}

			if ( isExistingItem ($item) )
			{
				echo "\n<br>Existing ITEM := " . $item->itm;
				continue;
			}

			saveEbayItem ($item);
		}

		///UK
		$target_url   = "https://www.ebay.co.uk/sch/m.html?_ssn=$username&_ipg=200&_sop=13&LH_Complete=1&LH_Sold=1&rt=nc";

		$contents   = getEbayUKPage ( $target_url );
				file_put_contents('UK.html', $contents);

		$feedbackScore = getValueByEnclosedString($contents, 'Feedback score of', 'href="');
		$feedbackScore = str_replace ('"', '', $feedbackScore);
		$feedbackScore = str_replace (' ', '', $feedbackScore);
		saveEbayFeedback($username,$feedbackScore);
		$contents   = getValueByEnclosedString($contents, 'id="Results"', 'id="PaginationAndExpansionsContainer"');
		$contents   = explode ('id="item', $contents);
		array_shift ($contents);

		foreach ($contents as $thisContent)
		{
			
			$item           = getBlankItem ();
			$item->scan_id  = $scan_id;
			$item->username = $username;

			$item->title  = cleanData(strip_tags(getValueByEnclosedString($thisContent, '<h3 class="lvtitle">', '</h3>')));
			$item->price  = cleanData(strip_tags(getValueByEnclosedString($thisContent, '<li class="lvprice prc">', '</')));
			$item->price  = str_replace ('Trending at', '', $item->price);
			$item->img    = cleanData(strip_tags(getValueByEnclosedString($thisContent, 'src="', '"')));
			$item->source = cleanData(strip_tags(getValueByEnclosedString($thisContent, '<a href="', '"')));

			preg_match_all ('/-\/(.*)\?hash=/', $item->source, $matches);
			$matches   = array_unique($matches[1]);
			$item->itm = array_shift ($matches);

			if ( $item->itm == '' )
			{
				preg_match_all ('/-\/(.*)\?var=/', $item->source, $matches);
				$matches   = array_unique($matches[1]);
				$item->itm = array_shift ($matches);
			}
			if ( isExistingItem ($item) ===TRUE)
			{
				echo "\n<br>Existing ITEM := " . $item->itm;
				continue;
			}
			saveEbayItem ($item);
		}
		
		updateEbayScanStatus ($id, 2); //done getting item
	}
	echo "\nENDED";