<?php
    define('DB_NAME', 'di287239_comp'); // The name of the database
    define('DB_USER', 'di287239_comp');     // Your MySQL username
    define('DB_PASSWORD', 'xxx'); // ...and password
    define('DB_HOST', 'localhost');     //IP ...and the server MySQL is running on


    $dbconn = @mysql_pconnect(DB_HOST, DB_USER, DB_PASSWORD) or die("DB ERROR " . mysql_error());

    mysql_query('SET names=utf8');
    mysql_query('SET character_set_client=utf8');
    mysql_query('SET character_set_connection=utf8');
    mysql_query('SET character_set_results=utf8');
    mysql_query('SET collation_connection=utf8_general_ci');

    @mysql_select_db(DB_NAME, $dbconn) or die("DB ERROR");

    define ('USE_PROXY', FALSE);
    $avg_use_count = FALSE;
    define ('PROXY_TABLE_NAME', '`proxy_ip`');

	function getBlankItem ()
	{
        $item               = new stdClass ( );
        $item->scan_id      = ''; 
		$item->username     = '';
		$item->itm          = '';
		$item->title        = '';
		$item->img          = '';
		$item->price        = '';
		$item->available    = '';
		$item->source       = '';
		$item->date_added   = date('Y-m-d H:i:s');
		$item->sold_status  = 0;

		return $item;
	}

	function getEbayUSAPage ( $url )
	{
	    $headers   = array ( );
	    $headers[] = 'Host: www.ebay.com';
	    $headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0';
	    $headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
	    $headers[] = 'Accept-Language: en-US,en;q=0.5';
	    $headers[] = 'Cookie: nonsession=CgADLAAFZaf9BOQDKACBiz/m5NDVmMGI2MmIxNWQwYWIxMzE5YjU0ZTM3ZmE4MmNiOTCW+ddx; ebay=%5Esbf%3D%2340c00000000010000100200%5Ejs%3D1%5Epsi%3DA8ZTKGqA*%5E; s=CgAD4ACBZa0m5NDVmMGI2MmIxNWQwYWIxMzE5YjU0ZTM3ZmE4MmNiOTDXXRzU; ds2=sotr/b7piCzQMzzzz^; dp1=btzo/-1685d2c5f46^u1p/QEBfX0BAX19AQA**5b4b2bb9^bl/US5d2c5f39^pbf/#100020000005d2c5f46^; JSESSIONID=8ECFD3332B0D7FABBB40B70136ED845C; ns1=BAQAAAV05Prk4AAaAANgASVtLK7ljNjl8NjAxXjE1MDAxMTY5OTQyMDZeXjFeM3wyfDV8NHw3XjFeMl40XjNeMTJeMTJeMl4xXjFeMF4xXjBeMV42NDQyNDU5MDc1GlT+Rgn45izVbctRYv+Qe1AFX8M*; npii=btguid/45f0b62b15d0ab1319b54e37fa82cb905b4b2bbc^cguid/45f0d3b115d0a9c15e53f76ff94386505b4b2bbc^; AMCV_A71B5B5B54F607AB0A4C98A2%40AdobeOrg=-1758798782%7CMCIDTS%7C17363%7CMCMID%7C60508294800272239030023717496386272171%7CMCAAMLH-1500721795%7C7%7CMCAAMB-1500721826%7CNRX38WO0n5BH8Th-nqAG_A%7CMCCIDH%7C759851302%7CMCOPTOUT-1500124226s%7CNONE%7CMCAID%7CNONE; __gads=ID=ac6e526a2dc67e26:T=1500116999:S=ALNI_MY2YZVASky8IiqNKJG0W2jBa-IaNQ; AMCVS_A71B5B5B54F607AB0A4C98A2%40AdobeOrg=1; aam_uuid=60494643078415193300024941360488841750';
	    $headers[] = 'Connection: keep-alive';
	    $headers[] = 'Upgrade-Insecure-Requests: 1';

$headers   = array ( );
$headers[] = 'Host: www.ebay.com';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0';
$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
$headers[] = 'Accept-Language: en-US,en;q=0.5';
$headers[] = 'Referer: https://www.ebay.com/sch/sunglasstop/m.html?_trksid=p3692';
$headers[] = 'Cookie: nonsession=CgAAIABxZkaCzMTUwMDExOTI0NHgyOTIwOTY1MjM3NTV4MHgyTgDLAAJZahq7NDQAygAgYtAVMzQ2MDNjMGRkMTVkMGE5YzQ1M2MyZDRmZWZjMzRlNDEzf+QAxw**; npii=btguid/4603c0dd15d0a9c453c2d4fefc34e4135b4b4736^cguid/4603cf1615d0aa4662712972fc25ed905b4b4736^; dp1=btzo/-1685d2c7ac3^idm/1596b51a8^u1p/QEBfX0BAX19AQA**5b4b4733^bl/GB5d2c7ab3^pbf/%2367000000008000e000008100020000005b4b4733^; AMCV_A71B5B5B54F607AB0A4C98A2%40AdobeOrg=-1758798782%7CMCIDTS%7C17363%7CMCMID%7C51499291300965231052746071653827562455%7CMCAAMLH-1500723881%7C3%7CMCAAMB-1500728860%7CNRX38WO0n5BH8Th-nqAG_A%7CMCCIDH%7C775122586%7CMCOPTOUT-1500131260s%7CNONE%7CMCAID%7CNONE; __gads=ID=6b1ee0051fcb03db:T=1500119086:S=ALNI_MapcjEFMTHCZXD8e69J6BKDIJsLGQ; aam_uuid=51489949691570623642742937881052901994; ebay=%5Esbf%3D%2340800000000010000100000%5Ecos%3D1%5Ecv%3D15555%5Ejs%3D1%5Epsi%3DAXOGTiHM*%5E; s=CgAD4ACBZa2UzNDYwM2MwZGQxNWQwYTljNDUzYzJkNGZlZmMzNGU0MTOmT6aQ; AMCVS_A71B5B5B54F607AB0A4C98A2%40AdobeOrg=1; JSESSIONID=1304CF5E270CA3A0EF0377E339910EF5; ns1=BAQAAAV05Prk4AAaAANgASVtLRzNjNjl8NjAxXjE1MDAxMjQwNjAwMTBeXjFeM3wyfDV8NHw3XjFeMl40XjNeMTJeMTJeMl4xXjFeMF4xXjBeMV42NDQyNDU5MDc1+ZQknpAt+UgvZimN7z2CrvPg+XY*; cssg=4603c0dd15d0a9c453c2d4fefc34e413; ds2=sotr/b7piCzQMz1Rj^ssts/1500124099535^';
$headers[] = 'Connection: keep-alive';
$headers[] = 'Upgrade-Insecure-Requests: 1';

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0');

	    if ( USE_PROXY )
	    {
	        /*
	        global $avg_use_count;
	        
	        if ( ! $avg_use_count )
	        {
	           $avg_use_count = getAvgUseCount();
	        }
	        
	        $randomIp   = getRandomIp($avg_use_count);
	        */
	        $randomIp   = getRandomIp();
	        $proxy_port = $randomIp->port;
	        $proxy_ip   = $randomIp->ip;
	        $loginpassw = $randomIp->user.':'.$randomIp->pass;
		     //dumpVar ($randomIp);
	        updateUse($randomIp);
	        
	        curl_setopt($ch, CURLOPT_PROXYPORT, $proxy_port);
	        curl_setopt($ch, CURLOPT_PROXYTYPE, 'HTTP');
	        curl_setopt($ch, CURLOPT_PROXY, $proxy_ip);
	        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $loginpassw);
	    }
	
	    //curl_setopt($ch, CURLOPT_PROXYPORT, $proxy_port);
	    //curl_setopt($ch, CURLOPT_PROXYTYPE, 'HTTP');
	    //curl_setopt($ch, CURLOPT_PROXY, $proxy_ip);
	    //curl_setopt($ch, CURLOPT_PROXYUSERPWD, $loginpassw);
	
	    $contents = curl_exec($ch);
	    sleep (1);
	    curl_close($ch);
	
	    /*
	    if (strpos ($result, '<title>Captcha page | PagineGialle.it</title>') !== false)
	    {
	       echo "\nChange IP at :"  . $url;
	       exit;
	    }
	    */

		return $contents;
	}

	function getEbayUKPage ( $url )
	{
		$headers   = array ( );
		$headers[] = 'Host: www.ebay.co.uk';
		$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0';
		$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
		$headers[] = 'Accept-Language: en-US,en;q=0.5';
		$headers[] = 'Cookie: JSESSIONID=FEE748471856B9615C3FEE08943DE4D6; ebay=%5Esbf%3D%2340c00000000010000100200%5Epsi%3DAA8e8ZnQ*%5Ejs%3D1%5E; ns1=BAQAAAV05Prk4AAaAANgATFtLMGRjNzJ8NjAxXjE1MDAxMTgyMzkxODleXjFeM3wyfDV8NHw3fDExXjFeMl40XjNeMTJeMTJeMl4xXjFeMF4xXjBeMV42NDQyNDU5MDc1K2iYlRdmOt289urhgOo+sDdr2MM*; dp1=bu1p/QEBfX0BAX19AQA**5b4b3064^bl/GB5d2c63e4^pbf/%23100020000005b4b3064^tzo/-1685d2c63f8^; s=CgAD4ACBZa05kNDYwM2M3YmMxNWQwYWExNjY3NDJhY2E5ZmU3NDIxYTFkY3ic; nonsession=CgADLAAFZagPsMgDKACBiz/5kNDYwM2M3YmMxNWQwYWExNjY3NDJhY2E5ZmU3NDIxYTFJhCh+; npii=btguid/4603c7bc15d0aa166742aca9fe7421a15b4b3062^cguid/4603cf1615d0aa4662712972fc25ed905b4b3062^; AMCV_A71B5B5B54F607AB0A4C98A2%40AdobeOrg=-1758798782%7CMCIDTS%7C17363%7CMCMID%7C51499291300965231052746071653827562455%7CMCAAMLH-1500723045%7C6%7CMCAAMB-1500723045%7CcIBAx_aQzFEHcPoEv0GwcQ%7CMCCIDH%7C775122586%7CMCOPTOUT-1500125445s%7CNONE%7CMCAID%7CNONE; __gads=ID=2deae23d39cbcdca:T=1500118250:S=ALNI_MYSdBHYQmrZXeLQlqhbJ2sS3PcBiw; AMCVS_A71B5B5B54F607AB0A4C98A2%40AdobeOrg=1; aam_uuid=51489949691570623642742937881052901994; ds2=sotr/b7piCzQMzzzz^';
		$headers[] = 'Connection: keep-alive';
		$headers[] = 'Upgrade-Insecure-Requests: 1';
		$headers[] = 'Cache-Control: max-age=0';

$headers   = array ( );
$headers[] = 'Host: www.ebay.co.uk';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0';
$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
$headers[] = 'Accept-Language: en-US,en;q=0.5';
$headers[] = 'Referer: https://www.ebay.co.uk/sch/**sleepingforest**/m.html?_nkw&_armrs=1&_ipg&_from&LH_Complete=1&LH_Sold=1&rt=nc&_trksid=p2046732.m1684';
$headers[] = 'Cookie: ns1=BAQAAAV05Prk4AAaAANgATFtLQvVjNzJ8NjAxXjE1MDAxMTgyMzkxODleXjFeM3wyfDV8NHw3fDExXjFeMl40XjNeMTJeMTJeMl4xXjFeMF4xXjBeMV42NDQyNDU5MDc1kg9IxvJTpwu9YZiVHSNsfg2dH+I*; dp1=btzo/-1685d2c767c^idm/1596b5271^u1p/QEBfX0BAX19AQA**5b4b42f5^bl/GB5d2c7675^pbf/#18008000e000000100020000005d2c7676^; nonsession=CgAAIABxZkZx1MTUwMDExOTI2MngzMjEzNTc1OTAzNTh4M3gyTgDLAAJZahZ9MTMAygAgYtAQ9TQ2MDNjN2JjMTVkMGFhMTY2NzQyYWNhOWZlNzQyMWExLH23cg**; npii=btguid/4603c7bc15d0aa166742aca9fe7421a15b4b42f6^cguid/4603cf1615d0aa4662712972fc25ed905b4b42f6^; AMCV_A71B5B5B54F607AB0A4C98A2%40AdobeOrg=-1758798782%7CMCIDTS%7C17363%7CMCMID%7C51499291300965231052746071653827562455%7CMCAAMLH-1500723045%7C6%7CMCAAMB-1500727715%7CcIBAx_aQzFEHcPoEv0GwcQ%7CMCCIDH%7C775122586%7CMCOPTOUT-1500130115s%7CNONE%7CMCAID%7CNONE; __gads=ID=2deae23d39cbcdca:T=1500118250:S=ALNI_MYSdBHYQmrZXeLQlqhbJ2sS3PcBiw; aam_uuid=51489949691570623642742937881052901994; JSESSIONID=9F04F16EAED3DBD3487B68B9C8B280E2; ebay=%5Esbf%3D%2340400000000010000100200%5Ejs%3D1%5Epsi%3DATGGamxM*%5E; s=CgAD4ACBZa2D1NDY0YTExMTIxNWQwYTk5MGI2OTcwYjcxZmU3NTU0YWKdaPMe; ds2=sotr/b7piCzzzzzzz^; AMCVS_A71B5B5B54F607AB0A4C98A2%40AdobeOrg=1';
$headers[] = 'Connection: keep-alive';
$headers[] = 'Upgrade-Insecure-Requests: 1';
$headers[] = 'Cache-Control: max-age=0';

$headers   = array ( );
$headers[] = 'Host: www.ebay.co.uk';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0';
$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
$headers[] = 'Accept-Language: en-US,en;q=0.5';
$headers[] = 'Referer: https://www.ebay.co.uk/sch/infinity-pro-store/m.html?_nkw=&_armrs=1&_ipg=&_from=';
$headers[] = 'Cookie: ns1=BAQAAAV05Prk4AAaAANgATFtLRgFjNzJ8NjAxXjE1MDAxMTgyMzkxODleXjFeM3wyfDV8NHw3fDExXjFeMl40XjNeMTJeMTJeMl4xXjFeMF4xXjBeMV42NDQyNDU5MDc12EgF1Z2AYBRlvwM+3k7rKOAhi+w*; dp1=btzo/-1685d2c7989^idm/1596b5271^u1p/QEBfX0BAX19AQA**5b4b4601^bl/GB5d2c7981^pbf/#63000018008000e000000100020000005d2c7980^; nonsession=BAQAAAV05Prk4AAaAAAgAHFmRn4ExNTAwMTE5MjYyeDMyMTM1NzU5MDM1OHgzeDJOADMAC1tLRgFFQzFBMUFBLEdCUgDLAAJZahmJNDEAygAgYtAUATQ2MDNjN2JjMTVkMGFhMTY2NzQyYWNhOWZlNzQyMWExtld5DnYJpUFKeNcWmN7jKYyRxuE*; npii=btguid/4603c7bc15d0aa166742aca9fe7421a15b4b45fc^cguid/4603cf1615d0aa4662712972fc25ed905b4b45fc^; AMCV_A71B5B5B54F607AB0A4C98A2%40AdobeOrg=-1758798782%7CMCIDTS%7C17363%7CMCMID%7C51499291300965231052746071653827562455%7CMCAAMLH-1500723045%7C6%7CMCAAMB-1500727715%7CcIBAx_aQzFEHcPoEv0GwcQ%7CMCCIDH%7C775122586%7CMCOPTOUT-1500130115s%7CNONE%7CMCAID%7CNONE; __gads=ID=2deae23d39cbcdca:T=1500118250:S=ALNI_MYSdBHYQmrZXeLQlqhbJ2sS3PcBiw; aam_uuid=51489949691570623642742937881052901994; JSESSIONID=DF526953D2FDCC1B0FFD055078177704; ebay=%5Esbf%3D%2340400000000010000100200%5Ejs%3D1%5Epsi%3DAWDOZ9nQ*%5E; s=CgAD4ACBZa2QBNDYwM2M3YmMxNWQwYWExNjY3NDJhY2E5ZmU3NDIxYTEA7gAvWWtkATMGaHR0cHM6Ly93d3cuZWJheS5jby51ay9zY2gvKipzbGVlcGluZ2ZvcmVzdCoqANkeEw**; ds2=sotr/b7piCzzzzzzz^; AMCVS_A71B5B5B54F607AB0A4C98A2%40AdobeOrg=1';
$headers[] = 'Connection: keep-alive';
$headers[] = 'Upgrade-Insecure-Requests: 1';
$headers[] = 'Cache-Control: max-age=0';

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0');

	    if ( USE_PROXY )
	    {
	        /*
	        global $avg_use_count;
	        
	        if ( ! $avg_use_count )
	        {
	           $avg_use_count = getAvgUseCount();
	        }
	        
	        $randomIp   = getRandomIp($avg_use_count);
	        */
	        $randomIp   = getRandomIp();
	        $proxy_port = $randomIp->port;
	        $proxy_ip   = $randomIp->ip;
	        $loginpassw = $randomIp->user.':'.$randomIp->pass;
		     //dumpVar ($randomIp);
	        updateUse($randomIp);
	        
	        curl_setopt($ch, CURLOPT_PROXYPORT, $proxy_port);
	        curl_setopt($ch, CURLOPT_PROXYTYPE, 'HTTP');
	        curl_setopt($ch, CURLOPT_PROXY, $proxy_ip);
	        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $loginpassw);
	    }
	
	    //curl_setopt($ch, CURLOPT_PROXYPORT, $proxy_port);
	    //curl_setopt($ch, CURLOPT_PROXYTYPE, 'HTTP');
	    //curl_setopt($ch, CURLOPT_PROXY, $proxy_ip);
	    //curl_setopt($ch, CURLOPT_PROXYUSERPWD, $loginpassw);
	
	    $contents = curl_exec($ch);
	    sleep (1);
	    curl_close($ch);
	
	    /*
	    if (strpos ($result, '<title>Captcha page | PagineGialle.it</title>') !== false)
	    {
	       echo "\nChange IP at :"  . $url;
	       exit;
	    }
	    */

		return $contents;
	}

	function getEbayPage ( $url )
	{
		$headers   = array ( );
		$headers[] = 'Host: www.ebay.com';
		$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0';
		$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
		$headers[] = 'Accept-Language: en-US,en;q=0.5';
		$headers[] = 'Cookie: npii=btguid/34b00f2b15b0a994e36220f7ff43de405b478eb3^trm/svid%3D1110039388720353585b478eb3^cguid/34b00b3915b0abc227b3c21aff56b5275b478eb3^; dp1=bu1p/QEBfX0BAX19AQA**5b48f0d7^bl/BD5d2a2457^pbf/%2320000008000e000008100420000045b48f0d7^; nonsession=BAQAAAV05Prk4AAaAAAgAHFmPSlcxNDk5OTcwODkyeDI3Mjc0MzYzNDEyNHgweDJOADMACVtI8Nc5ODY3NSxVU0EAywABWWfEXzIAygAgYs2+1zM0YjAwZjJiMTViMGE5OTRlMzYyMjBmN2ZmNDNkZTQwA30zt9dipkE0JEPjiiv0E7tjZUc*; ns1=BAQAAAV05Prk4AAaAANgASVtI8NdjNjl8NjAxXjE0OTQxMjQ1Njk4OTheXjFeM3wyfDV8NHw3XjFeMl40XjNeMTJeMTJeMl4xXjFeMF4xXjBeMV42NDQyNDU5MDc1WMlpONPfaKsLLFjRKUkFUZwM+Xo*; __gads=ID; AMCV_A71B5B5B54F607AB0A4C98A2%40AdobeOrg=-1758798782%7CMCIDTS%7C17357%7CMCMID%7C87886709321307251121581925333327282663%7CMCAAMLH-1500189222%7C3%7CMCAAMB-1500189222%7CNRX38WO0n5BH8Th-nqAG_A%7CMCCIDH%7C449410404%7CMCOPTOUT-1499591622s%7CNONE%7CMCAID%7CNONE; aam_uuid=87897590236554376371583294903152916570; cid=a1GgTIiHaLoLe0w4%231903105492; ebay=%5Esbf%3D%2340c00000000010000100000%5Ejs%3D1%5Epsi%3DAO3NHD0Q*%5E; s=CgAD4ACBZaQ7XM2M5NTMyOGQxNWQwYWI2YjZhZTFlZmNmZmU5ZDFiODLDKcmy; JSESSIONID=04F329C4B11968E18A29FA60FC73C363; ds2=sotr/b7pwxzzzzzzz^ssts/1499970931965^';
		$headers[] = 'Connection: keep-alive';
		$headers[] = 'Upgrade-Insecure-Requests: 1';
		$headers[] = 'Cache-Control: max-age=0';

	    $headers   = array ();
	    $headers[] = 'Host: www.ebay.com';
	    $headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0';
	    $headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
	    $headers[] = 'Accept-Language: en-US,en;q=0.5';
	    $headers[] = 'Cookie: ns1=BAQAAAVP4UWlmAAaAANgASVjrifdjNjl8NjAxXjE0NTc2Nzg0OTI3MTheXjFeM3wyfDV8NHw3XjFeMl40XjNeMTJeMTJeMl4xXjFeMF4xXjBeMV42NDQyNDU5MDc1zgxMdrBJ43phv7hdpaw/0qb+s0w*; dp1=btzo/-1685accbde0^idm/1570ba716^u1p/QEBfX0BAX19AQA**58eb89f7^bl/BD5accbd77^pbf/#20000008000e000008100020000045accbdd9^; nonsession=BAQAAAVP4UWlmAAaAAAgAHFcx43cxNDYwMjk1MDUyeDI3MjE5MjczODE4N3gweDJOADMACVjrifc5NTY3OCxVU0EAywACVwpdfzEzAMoAIGBwV/c2NDY4YTQyMjE1MzBhYmMxYzI4MjQ5MWRmZmE5MmU1NSufH01dtcbr4mr/dDjIuhwtcWhj; npii=bcguid/6468b73b1530a56a0ab75237fc226a2858eb89fd^tguid/6468a4221530abc1c282491dffa92e5558eb89fd^; cid=izfHQXq7; JSESSIONID=87C402F4812365319F7595C4BA69CB8C; ebay=%5Esbf%3D%2340c00000000010000100000%5Ejs%3D1%5Epsi%3DAYRRnE4I*%5E; s=CgAD4ACBXC6f3MDA1ZTJkYTUxNTQwYTVlNmUzZTRiYTIyZmZmMWIwNTH63JHd; ds2=sotr/b7piCzzzzzzz^ssts/1460295392881^';
	    $headers[] = 'Connection: keep-alive';
	    $headers[] = 'Cache-Control: max-age=0';


$headers   = array ( );
$headers[] = 'Host: www.ebay.com';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0';
$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
$headers[] = 'Accept-Language: en-US,en;q=0.5';
$headers[] = 'Referer: http://185.24.234.250/EBAY-API/store_api/?seller=*boostprosales*';
$headers[] = 'Cookie: npii=btguid/34b00f2b15b0a994e36220f7ff43de405b4a2d18^trm/svid%3D1110039388720353585b4a2d18^cguid/34b00b3915b0abc227b3c21aff56b5275b4a2d18^; dp1=btzo/-1685d2b60b9^idm/1596924e2^u1p/QEBfX0BAX19AQA**5b4a2d36^bl/BD5d2b60b6^pbf/%2320010008000e000008100420000045b4a2d36^; nonsession=BAQAAAV05Prk4AAaAAAgAHFmQhrYxNTAwMDUxMDQ5eDIyMjA2NTA3MTM3N3gweDJOADMACVtKLTY5ODY3NSxVU0EAywACWWkAvjI3AMoAIGLO+zYzNGIwMGYyYjE1YjBhOTk0ZTM2MjIwZjdmZjQzZGU0MI4P7WnaVIvQlgizK0hxNEtAXOMB; ns1=BAQAAAV05Prk4AAaAANgASVtKLTZjNjl8NjAxXjE0OTQxMjQ1Njk4OTheXjFeM3wyfDV8NHw3XjFeMl40XjNeMTJeMTJeMl4xXjFeMF4xXjBeMV42NDQyNDU5MDc1RmSBvmnUEpPggwn6EpjnePCPce0*; __gads=ID=49c12281dec8d869:T=1499970942:S=ALNI_Mam68ffl3rWWhfvNHgmRcI1M1BXZg; cid=a1GgTIiHaLoLe0w4%231903105492; ebay=%5Esbf%3D%2340400000000010000100200%5Ecos%3D-2%5Ecv%3D15555%5Ejs%3D1%5Epsi%3DADvOzcZY*%5E; s=CgAD4ACBZaks2NDE0ZDhlM2QxNWQwYWJkYTZhYTVjNWZhZmU5MDQ2MDli6hyY; JSESSIONID=5B9DDD491D6F8061943AD90D40E67893; cssg=414d8e3d15d0abda6aa5c5fafe904609; ds2=sotr/b7piCzzzzzzz^ssts/1500051897285^';
$headers[] = 'Connection: keep-alive';
$headers[] = 'Upgrade-Insecure-Requests: 1';
$headers[] = 'Cache-Control: max-age=0';


        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0');

	    if ( USE_PROXY )
	    {
	        /*
	        global $avg_use_count;
	        
	        if ( ! $avg_use_count )
	        {
	           $avg_use_count = getAvgUseCount();
	        }
	        
	        $randomIp   = getRandomIp($avg_use_count);
	        */
	        $randomIp   = getRandomIp();
	        $proxy_port = $randomIp->port;
	        $proxy_ip   = $randomIp->ip;
	        $loginpassw = $randomIp->user.':'.$randomIp->pass;
		     //dumpVar ($randomIp);
	        updateUse($randomIp);
	        
	        curl_setopt($ch, CURLOPT_PROXYPORT, $proxy_port);
	        curl_setopt($ch, CURLOPT_PROXYTYPE, 'HTTP');
	        curl_setopt($ch, CURLOPT_PROXY, $proxy_ip);
	        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $loginpassw);
	    }
	
	    //curl_setopt($ch, CURLOPT_PROXYPORT, $proxy_port);
	    //curl_setopt($ch, CURLOPT_PROXYTYPE, 'HTTP');
	    //curl_setopt($ch, CURLOPT_PROXY, $proxy_ip);
	    //curl_setopt($ch, CURLOPT_PROXYUSERPWD, $loginpassw);
	
	    $contents = curl_exec($ch);
	    sleep (1);
	    curl_close($ch);
	
	    /*
	    if (strpos ($result, '<title>Captcha page | PagineGialle.it</title>') !== false)
	    {
	       echo "\nChange IP at :"  . $url;
	       exit;
	    }
	    */

		return $contents;
	}

	function q($str)
	{
	    return "'" . $str . "'";
	}

    function getNextProductAutoId()
    {
        $sql   = "SHOW TABLE STATUS LIKE 'yelp_records';";
        $resut = mysql_query ($sql);
        $row   = mysql_fetch_object ($resut);

        return $row->Auto_increment;
    }

    function updateUse($randomIp)
    {
        $id        = $randomIp->id;
        $last_used = date ('Y-m-d H:i:s');

        $sql = "UPDATE ". PROXY_TABLE_NAME ."  SET `last_used` = '$last_used', `use_count`=(`use_count`+1) WHERE `id`='$id';";
        $result = mysql_query ($sql);

        return TRUE;
    }

    function updateBanStatus($randomIp, $is_banned)
    {
        $id        = $randomIp->id;
        $banned_on = date ('Y-m-d H:i:s');

        $sql = "UPDATE ". PROXY_TABLE_NAME ."  SET `banned_on` = '$banned_on', `is_banned`='$is_banned' WHERE `id`='$id';";
        $result = mysql_query ($sql);

        return TRUE;
    }

    function getRandomIp($avg_use_count = null)
    {
        //$sql    = "SELECT * FROM ". PROXY_TABLE_NAME ."  WHERE `is_banned`='0' AND `use_count` <= '$avg_use_count' ORDER BY RAND() LIMIT 1;";
        $sql    = "SELECT * FROM ". PROXY_TABLE_NAME ."  WHERE `is_banned`='0' ORDER BY RAND() LIMIT 1;";
        $result = mysql_query ($sql);
        $row    = mysql_fetch_object ($result);

        return $row;
    }

    function getAvgUseCount()
    {
        $sql    = "SELECT AVG(use_count) AS avg_use_count FROM ". PROXY_TABLE_NAME ."  WHERE `is_banned`='0' AND `status`='1';";
        $result = mysql_query ($sql);
        $row    = mysql_fetch_object ($result);
        
        return floor($row->avg_use_count);//(int) sprintf ("%0.0f", $row->avg_use_count);
    }

	function isExistingResultURL ( $car_url )
	{
	    $car_url = mysql_real_escape_string(str_replace ('&amp;', '&', $car_url));
	    $query   = "SELECT * FROM `cars` WHERE `car_url`='$car_url';";
	    $result  = mysql_query($query);
	    $row     = mysql_fetch_object($result);
	    
	    if(isset($row->id))
	    {
			return TRUE;
	    }
	    else
	    {
			return FALSE;
	    }
	}

    function insertData($CONTACT)
    {
        $query = " INSERT INTO `business` SET `name`=" . q(mysql_real_escape_string(trim($CONTACT->name)))
               . " ,`yellowpages_scan_id`=" . q(mysql_real_escape_string(trim($CONTACT->yellowpages_scan_id)))
               . " ,`address`="          . q(mysql_real_escape_string(trim($CONTACT->address)))
               . " ,`city`="             . q(mysql_real_escape_string(trim($CONTACT->city)))
               . " ,`state`="            . q(mysql_real_escape_string(trim($CONTACT->state)))
               . " ,`zip`="              . q(mysql_real_escape_string(trim($CONTACT->zip)))
               . " ,`country`="          . q(mysql_real_escape_string(trim($CONTACT->country)))
               . " ,`phone`="            . q(mysql_real_escape_string(trim($CONTACT->phone)))
               . " ,`mobile`="           . q(mysql_real_escape_string(trim($CONTACT->mobile)))
               . " ,`fax`="              . q(mysql_real_escape_string(trim($CONTACT->fax)))
               . " ,`email`="            . q(mysql_real_escape_string(trim($CONTACT->email)))
               . " ,`website`="          . q(mysql_real_escape_string(trim($CONTACT->website)))
               . " ,`contact`="          . q(mysql_real_escape_string(trim($CONTACT->contact)))
               . " ,`designation`="      . q(mysql_real_escape_string(trim($CONTACT->designation)))
               . " ,`category`="         . q(mysql_real_escape_string(trim($CONTACT->category)))
               . " ,`keyword`="          . q(mysql_real_escape_string(trim($CONTACT->keyword)))
               . " ,`source`="           . q(mysql_real_escape_string(trim($CONTACT->source)))
               . " ,`data_domain`="      . q(mysql_real_escape_string(trim($CONTACT->data_domain)))
               . " ,`email_source`="     . q(mysql_real_escape_string(trim($CONTACT->email_source)))
               . " ,`auto_effort`="      . q(mysql_real_escape_string(trim($CONTACT->auto_effort)))
               . " ,`manual_effort`="    . q(mysql_real_escape_string(trim($CONTACT->manual_effort)))
               . " ,`social_collected`=" . q(mysql_real_escape_string(trim($CONTACT->social_collected)))
               . " ,`date_added`="       . q(mysql_real_escape_string(trim($CONTACT->date_added)))
               . " ,`date_updated`="     . q(mysql_real_escape_string(trim($CONTACT->date_updated)))
               . " ,`status`="           . q(mysql_real_escape_string(trim($CONTACT->status)));

        $result = @mysql_query($query) or die (mysql_error());

        return mysql_insert_id();
    }

    function isExistingSource($source)
    {
        $query  = "SELECT * FROM `mangago` WHERE `data_source`='$source'";
        $result = mysql_query($query);
        $row    = mysql_fetch_object($result);

        if(isset($row->id))
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
function getEbayStore($url,$host)
    {
        $headers   = array ( );
        $headers[] = 'Host: '.$host;
        $headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0';
        $headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
        $headers[] = 'Accept-Language: en-US,en;q=0.5';
        $headers[] = 'Referer: http://stores.ebay.com/';
        $headers[] = 'Connection: keep-alive';
        $headers[] = 'Upgrade-Insecure-Requests: 1';
        $headers[] = 'Cache-Control: max-age=0';

        $ch = curl_init ($url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_HEADER, TRUE);

        curl_setopt($ch, CURLOPT_NOBODY, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

        curl_setopt($ch, CURLOPT_REFERER, "http://$host");
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0');
		curl_setopt($ch,CURLOPT_ENCODING , "gzip");
        $contents = curl_exec($ch);
	    sleep (1);
		// Then, after your curl_exec call:
		$header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
		$header = substr($contents, 0, $header_size);
		$body = substr($contents, $header_size);
		curl_close($ch);
		return $body;
    }
    function getEbayItem($url,$host)
    {
        $headers   = array ( );
        $headers[] = 'Host: '.$host;
        $headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0';
        $headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
        $headers[] = 'Accept-Language: en-US,en;q=0.5';
        $headers[] = 'Referer: http://stores.ebay.com/';
        $headers[] = 'Connection: keep-alive';
        $headers[] = 'Upgrade-Insecure-Requests: 1';
        $headers[] = 'Cache-Control: max-age=0';

        $ch = curl_init ($url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_HEADER, TRUE);

        curl_setopt($ch, CURLOPT_NOBODY, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

        curl_setopt($ch, CURLOPT_REFERER, "http://$host");
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0');
		curl_setopt($ch,CURLOPT_ENCODING , "gzip");
        $contents = curl_exec($ch);
	    sleep (1);
		// Then, after your curl_exec call:
		$header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
		$header = substr($contents, 0, $header_size);
		$body = substr($contents, $header_size);
		curl_close($ch);
		return $body;
    }

    function getValueByEnclosedString($contents, $startString, $endString)
    {
        $mystring = $contents;
        $findme   = $startString;
        $pos      = strpos($mystring, $findme);

        if($pos === false)
        {
            return '';
        }

        $start   = strpos($contents, $startString) + strlen($startString);
        $end     = strpos($contents, $endString, $start);
        $length  = $end - $start;

        return  substr($contents, $start, $length);
    }

    function updateStart ($id, $start)
    {
        $sql = " UPDATE `www_krak_dk_pages` SET `start`='$start' WHERE `id`='$id' ";
        mysql_query ($sql);

        return TRUE;
    }

    function updateStatus ($id, $status)
    {
        return TRUE;

        $sql = " UPDATE `www_krak_dk_pages` SET `status`='$status' WHERE `id`='$id' ";
        mysql_query ($sql);

        return TRUE;
    }

    function cleanData ($data)
    {
        $data = str_replace  ('&amp;', '&', $data);
        $data = str_replace  ('&nbsp;', ' ', $data);
        $data = str_replace  ('&#39;', "'", $data);
        $data = str_replace  ('&ndash;', "�", $data);
        $data = preg_replace ('/\s+/', ' ', $data);
        $data = trim ( $data );

        return $data;
    }

    function dumpVar ( $message )
    {
        echo '<xmp>';
        print_r($message);
        echo '</xmp>';
    }
	
	function isValidEbayUser ($username)
	{
		$url       = "http://www.ebay.com/sch/$username/m.html";
		//$url       = "https://www.ebay.com/sch/always-party-eshop/m.html";
		$contents  = getEbayPage ( $url );

	    if ( strpos ($contents, 'One or more of the seller User IDs you entered was not found') !== false )
	    {
        	return FALSE;
	    }

        return TRUE;
	}

    function saveEbayItem ($item)
    {
        $query = " INSERT INTO `ebay_item` SET `scan_id`=" . q(mysql_real_escape_string(trim($item->scan_id)))
               . " ,`username`="       . q(mysql_real_escape_string(trim($item->username)))
               . " ,`itm`=" . q(mysql_real_escape_string(trim($item->itm)))
               . " ,`title`="       . q(mysql_real_escape_string(trim($item->title)))
               . " ,`img`=" . q(mysql_real_escape_string(trim($item->img)))
               . " ,`price`=" . q(mysql_real_escape_string(trim($item->price)))
               . " ,`source`=" . q(mysql_real_escape_string(trim($item->source)))
               . " ,`date_added`=" . q(mysql_real_escape_string(trim($item->date_added)))
               . " ,`sold_status`=" . q(mysql_real_escape_string(trim($item->sold_status)));

        $result = @mysql_query($query);// or die (mysql_error());

        return mysql_insert_id();
    }

    function isExistingSellerItem ($item)
    {
        $query  = "SELECT * FROM `ebay_seller_item` WHERE `scan_id`='"
                . $item->scan_id . "' AND `itm`='"
                . mysql_real_escape_string($item->itm) ."'"
                . " AND `days`='"
                . mysql_real_escape_string($item->days) ."'";

        $result = mysql_query($query);
        $row    = mysql_fetch_object($result);

        if(isset($row->id))
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }

    function isExistingItem ($item)
    {
        $query  = "SELECT * FROM `ebay_item` WHERE `scan_id`='"
                . $item->scan_id . "' AND `itm`='"
                . mysql_real_escape_string($item->itm) ."'";

        $result = mysql_query($query);
        $row    = mysql_fetch_object($result);

        if(isset($row->id))
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }

     function updateEbayScanStatus ($id, $data_status)
    {
        #return TRUE;

        $sql = " UPDATE `ebay_seller` SET `data_status`='$data_status' WHERE `id`='$id' ";
        mysql_query ($sql);

        return TRUE;
    }



    function updateSoldStatus ($id, $sold_status)
    {
         $sql = " UPDATE `ebay_item` SET `sold_status`='$sold_status' WHERE `id`='$id' ";
        mysql_query ($sql);

        return TRUE;
    }

	
	function saveEbayFeedback ($username, $feedback)
    {
        $sql = " UPDATE `ebay_seller` SET `feedback`='$feedback' WHERE `username`='$username' ";
        mysql_query ($sql);
        return TRUE;
    }

	function saveEbayCountry ($username, $country)
    {
        $sql = " UPDATE `ebay_seller` SET `country`='$country' WHERE `username`='$username' ";
        mysql_query ($sql);
        return TRUE;
    }
	
?>
