<?php
	//Turn off all error reporting
	//error_reporting(0);

	//Report all PHP errors
	error_reporting(-1);

	// Report simple running errors
	//error_reporting(E_ERROR | E_WARNING | E_PARSE);

	set_time_limit(0);
	require_once ('dbconnect.php');
    $msql    = "SELECT id,username,itm,source FROM `ebay_item` WHERE `sold_status`='0' ORDER BY id ASC LIMIT 0 , 50;";
    $mResult = mysql_query ($msql);
	
	while ( $mRow = mysql_fetch_object ($mResult))
    {
    	$id     = $mRow->id;
		$username     = $mRow->username;
		$itm =	$mRow->itm;
		$source    = $mRow->source;

		updateSoldStatus ($id, 1);//Processing Started		
		
		if ( strpos ($source, 'www.ebay.co.uk') !== false )
		{
			$url    = 'http://offer.ebay.co.uk/ws/eBayISAPI.dll?ViewBidsLogin&item='.$itm;
			$contents   = getEbayUKPage ( $url );			
		}
		else
		{
			$url    = 'http://offer.ebay.com/ws/eBayISAPI.dll?ViewBidsLogin&item='.$itm;
			$contents   = getEbayUSAPage ( $url );			
		}
		//file_put_contents('a.html', $contents);
		$internalErrors = libxml_use_internal_errors(true);
		$doc = new DOMDocument();
		$doc->loadHTML($contents);
		$xpath = new DOMXpath($doc);
		libxml_use_internal_errors($internalErrors);
		
		$values = array(); 
		
		$trNodes = $xpath->query("//table[@cellpadding='5']/tr");	
		for($i = 1; $i < $trNodes->length;$i++)
		{
			$td=$xpath->query(".//td",$trNodes->item($i));
			$priceString =$td->item(2)->nodeValue;
			$priceString =  str_replace( "US ","",$priceString);
			$priceString =  str_replace( "EU ","",$priceString);
			$priceString =  str_replace( "£","",$priceString);
			$priceString =  str_replace( "$","",$priceString);
			$price = floatval($priceString);
			$quantity =$td->item(3)->nodeValue;
			$dateString =$td->item(4)->nodeValue;
			$date = date_create_from_format('d-M-y H:i:s T', $dateString);
			if (!$date instanceof DateTime){
			$date = date_create_from_format('M-d-y H:i:s T', $dateString);
			}
			if ($date instanceof DateTime){
				$values[] = "(NULL,".q($username).", "
					 .q($id).", "
					 .$price.", "
					 .$quantity.", "
					 ."FROM_UNIXTIME(".$date->getTimestamp()."))";
			}else{
				$priceString =$td->item(3)->nodeValue;
				$priceString =  str_replace( "US ","",$priceString);
				$priceString =  str_replace( "EU ","",$priceString);
				$priceString =  str_replace( "£","",$priceString);
				$priceString =  str_replace( "$","",$priceString);
				$price = floatval($priceString);
				$quantity =$td->item(4)->nodeValue;
				$dateString =$td->item(5)->nodeValue;
				$date = date_create_from_format('d-M-y H:i:s T', $dateString);
				if (!$date instanceof DateTime){
				$date = date_create_from_format('M-d-y H:i:s T', $dateString);
				}
				if ($date instanceof DateTime){
					$values[] = "(NULL,".q($username).", "
						 .q($id).", "
						 .$price.", "
						 .$quantity.", "
						 ."FROM_UNIXTIME(".$date->getTimestamp()."))";
				}
			}
		}
		
		$sql='INSERT INTO `ebay_purchase_history` (`id`,`seller`, `item_id`, `price`, `quantity`, `purchase_date`) VALUES '.implode(',', $values).';';
		mysql_query($sql);	
		//echo 'sql:'.$sql;
		
		$contents   = getEbayItem ('http://www.ebay.com/itm/'.$itm,'www.ebay.com');			
		$sold   = getValueByEnclosedString($contents, '"qtyPurchased":', ',');
		$available   = getValueByEnclosedString($contents, '"remainingQty":', ',');
		$sql = "UPDATE `ebay_item` SET `sold` = '$sold', `available` = '$available',`date_updated`= NOW() WHERE `ebay_item`.`id` = $id;";

        mysql_query ($sql);	
		
		updateSoldStatus ($id, 2);//DONE
	}


	echo "\nENDED";